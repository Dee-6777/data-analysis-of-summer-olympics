# data-analysis-of-summer-olympics
in this project i have done data analysis which is based on summer olympics , it includes 8 small codes based on the asked question.
